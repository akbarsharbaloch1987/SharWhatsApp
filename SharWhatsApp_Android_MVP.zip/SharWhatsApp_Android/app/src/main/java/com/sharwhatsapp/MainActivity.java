package com.sharwhatsapp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int green = Color.rgb(0, 128, 105);
    private final ArrayList<String> messages = new ArrayList<>();
    private LinearLayout root, messageList;
    private EditText composer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void showHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(246, 248, 247));
        setContentView(root);

        TextView header = text("  SharWhatsApp", 25, Color.WHITE);
        header.setTypeface(null, Typeface.BOLD);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(green);
        header.setPadding(12, 18, 12, 18);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView tagline = text("  Simple. Private. Connected.", 13, Color.DKGRAY);
        tagline.setPadding(12, 12, 12, 12);
        root.addView(tagline);

        addChat("Ayesha", "Hi! Welcome to SharWhatsApp.", "A");
        addChat("Family Group", "Let's plan this weekend.", "F");
        addChat("Ali", "How are you?", "A");
        addChat("Work Team", "Project update shared.", "W");

        TextView note = text("Demo contacts · Messages stay on this device", 12, Color.GRAY);
        note.setGravity(Gravity.CENTER);
        note.setPadding(8, 18, 8, 12);
        root.addView(note);
    }

    private void addChat(String name, String preview, String initial) {
        LinearLayout item = new LinearLayout(this);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(14, 14, 14, 14);
        TextView avatar = text(initial, 20, Color.WHITE);
        avatar.setGravity(Gravity.CENTER);
        avatar.setTypeface(null, Typeface.BOLD);
        avatar.setBackgroundColor(green);
        item.addView(avatar, new LinearLayout.LayoutParams(52, 52));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(14, 0, 0, 0);
        TextView title = text(name, 18, Color.BLACK);
        title.setTypeface(null, Typeface.BOLD);
        details.addView(title);
        details.addView(text(preview, 14, Color.DKGRAY));
        item.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        item.setOnClickListener(v -> showChat(name));
        root.addView(item, new LinearLayout.LayoutParams(-1, -2));

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(225, 230, 228));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.leftMargin = 78;
        root.addView(line, lp);
    }

    private void showChat(String name) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(239, 245, 241));
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(green);
        TextView back = text("‹", 34, Color.WHITE);
        back.setPadding(16, 4, 16, 4);
        back.setOnClickListener(v -> showHome());
        bar.addView(back);
        TextView title = text(name, 20, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(-1, 58));

        messageList = new LinearLayout(this);
        messageList.setOrientation(LinearLayout.VERTICAL);
        messageList.setPadding(12, 12, 12, 12);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(messageList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        if (messages.isEmpty()) {
            addBubble("Welcome to your " + name + " chat. Send a message below to try the app.", false);
        } else {
            for (String m : messages) addBubble(m, true);
        }

        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setPadding(8, 8, 8, 8);
        sendRow.setGravity(Gravity.CENTER_VERTICAL);
        sendRow.setBackgroundColor(Color.WHITE);
        composer = new EditText(this);
        composer.setSingleLine(true);
        composer.setHint("Message");
        sendRow.addView(composer, new LinearLayout.LayoutParams(0, 52, 1));
        Button send = new Button(this);
        send.setText("Send");
        send.setTextColor(Color.WHITE);
        send.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        send.setOnClickListener(v -> {
            String value = composer.getText().toString().trim();
            if (!value.isEmpty()) {
                messages.add(value);
                addBubble(value, true);
                composer.setText("");
            }
        });
        sendRow.addView(send);
        root.addView(sendRow);
    }

    private void addBubble(String value, boolean mine) {
        TextView bubble = text(value, 16, Color.rgb(25, 35, 30));
        bubble.setPadding(14, 10, 14, 10);
        bubble.setBackgroundColor(mine ? Color.rgb(210, 244, 220) : Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = mine ? Gravity.RIGHT : Gravity.LEFT;
        p.setMargins(4, 5, 4, 5);
        messageList.addView(bubble, p);
    }
}
