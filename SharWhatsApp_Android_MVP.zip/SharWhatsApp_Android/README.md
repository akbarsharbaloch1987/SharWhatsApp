# SharWhatsApp Android MVP

A native Android starter project for SharWhatsApp.

## Requirements
- Android Studio (recommended) with Android SDK 35
- JDK 17
- Android phone running Android 6.0 or newer

## Build APK
1. Extract this ZIP.
2. Open the `SharWhatsApp_Android` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. If prompted, allow installation from that source.

## Current limitations
This is an offline UI prototype. Demo contacts are not real phone contacts. Messages are held in memory while the app process is running and are not sent to other users. No account system, server, encryption, voice/video calls, notifications, or media upload is included yet.

## Next development stage
Add account registration, secure backend messaging, persistent message storage, push notifications, and end-to-end encryption before using it for real private conversations.
